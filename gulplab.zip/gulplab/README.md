
Remember to do run the `npm install` 

$gulp hello


$gulp build     // to build the app

To run

$gulp


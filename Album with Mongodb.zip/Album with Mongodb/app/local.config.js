

exports.config = {
    db_config: {
        host: "localhost",
        // use default "port"
        poolSize: 20
    },

    static_content: "../static/"
};


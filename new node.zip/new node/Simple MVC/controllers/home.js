var template = require('../views/template-main');  //view
var test_data = require('../model/test-data');   // model

exports.get = function(req, res) {  
  var teamlist = test_data.teamlist;
  var strTeam = "",
    i = 0;
  for (i = 0; i < teamlist.count;) {
    strTeam = strTeam + "<li>" + teamlist.teams[i].country + "</li>";
    i = i + 1;
  }
  strTeam = "<ul>" + strTeam + "</ul>";
  res.writeHead(200, {
    'Content-Type': 'text/html'
  });

    // build is our own function written template-main view. (Observe in views folder)
  res.write(template.build
      ("Test web page on node.js", "Hello there", "<p>The teams in football Group " +
           teamlist.GroupName + " for 2016 are:</p>" + strTeam));
  res.end();
};



/*

The controller (normally) performs some operations 
using the response from the model

The controller sends a response to the view

*/
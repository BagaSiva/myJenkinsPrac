// Model ... get it from mongo db or mysql
var thelist = function () {
  var objJson = {
    "GroupName": "D",
    "count": 4,
    "teams": [{
      "country": "England"
    }, {
      "country": "Australia"
    }, {
      "country": "Sweden"
    }, {
      "country": "India"
    }]
  };
  return objJson;
};
exports.teamlist = thelist(); 
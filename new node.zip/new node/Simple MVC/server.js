var host = '127.0.0.1';  
var port = 8000;  
var http = require('http');  
var server = http.createServer(function(req, res) {  
  require('./router').get(req, res);
}); // end server()

server.listen(port, host);  
console.log('listening to http://' + host + ':' + port);


//node server.js

//localhost:8000  
// localhsot:8000/xyz    (shows 404 error)
var url = require('url');  
var fs = require('fs');

exports.get = function(req, res) {  
    req.requrl = url.parse(req.url, true);

  var path = req.requrl.pathname;
  if (/.(css)$/.test(path)) {
    res.writeHead(200, {
      'Content-Type': 'text/css'
    });

    fs.readFile(__dirname + path, 'utf8', function (err, data) {
      if (err) throw err;
      res.write(data, 'utf8');
      res.end();
    });
  } else {
    if (path === '/' || path === '/home') {
      require('./controllers/home').get(req, res);
    } else {
      require('./controllers/404').get(req, res);
    }
  }
};

/*
Above steps:

Importing the URL and FileSystem (fs) modules that come 
as part of your node.js install

Exporting a function called “get” – this allows our server 
file to use this function, passing the request and 
response objects through

Getting the path of the URL request

Testing to see whether the request is for a CSS file 
and loading it in if so. 

Sending the request to the correct controller, 
if it’s not for a CSS file

*/
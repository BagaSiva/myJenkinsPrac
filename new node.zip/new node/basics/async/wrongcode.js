﻿
for (var i = 0; i < 10; i++) {
    process.nextTick(function () {
        console.log(i);
    });
}
console.log("you might this this gets printed last!")

// node wrongcode.js    (this is sync code)
// Solution is async



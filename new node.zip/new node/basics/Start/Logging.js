﻿// Logging
//npm install log4js -g

var log4js = require('log4js');
var logger = log4js.getLogger();

logger.info('Application is running');
logger.warn('Module cannot be loaded');
logger.error('Saved data was error');
logger.fatal('Server could not process');
logger.debug("Some debug messages");

/*
// for colors
var log4js = require('log4js');
var logger = log4js.getLogger('myapplication');  // just add category
logger.info('Application is running');
logger.warn('Module cannot be loaded');
logger.error('Saved data was error');
logger.fatal('Server could not process');
logger.debug("Some debug messages");
*/

// to log into file  add below code
log4js.loadAppender('file');
log4js.addAppender(log4js.appenders.file('myapplication.log'), 'myapplication');
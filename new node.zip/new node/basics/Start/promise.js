﻿try {
    setTimeout(function () {
        throw new Error("Uh oh!");
    }, 2000);
} catch (e) {
    console.log("I caught the error: " + e.message);
}
// run above code, observe error  uh oh! null:............

/*

In reality, the call to setTimeout does execute within the try ... catch block. 

If that function were to throw an error, the catch block would catch it, and  would see the message
that we had hoped to see. Timeout function just adds an event to the Node
event queue (instructing it to call the provided function after the specified time interval—
2000ms i), and then returns. The provided callback function actually operates
within its own entirely new context and scope!

As a result, when we call asynchronous functions for nonblocking IO, very few of them throw
errors, but instead use a separate way of telling  that something has gone wrong.
*/

// solution - callback  (PROMISE (Reject, Resolve)
var fs=require('fs');
fs.open(
'info.txt', 'r',
function (err, handle) {
    if (err) {
        console.log("ERROR: " + err.code + " (" + err.message +")");
        return;
    }
    // success!! continue working here
}
);


var fs = require('fs');
fs.open(
'info.txt', 'r',
function (err, handle) {
    if (err) {
        console.log("ERROR: " + err.code
        + " (" + err.message + ")");
        return;
    }
    var buf = new Buffer(100000);
    fs.read(
    handle, buf, 0, 100000, null,
    function (err, length) {
        if (err) {
            console.log("ERROR: " + err.code +
            " (" + err.message + ")");
            return;
        }
        console.log(buf.toString('utf8', 0, length));
        fs.close(handle, function () { /* don't care */ });
    }
    );
}
);
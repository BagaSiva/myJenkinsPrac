﻿process.stdin.setEncoding('utf8');
console.log("Type your text and press enter to terminate  line (ctrl+c to stop):")
process.stdin.on('readable', function () {
    var chunk = process.stdin.read();
    if (chunk !== null) {
        process.stdout.write('You typed : ' + chunk);
    }
});

process.stdin.on('end',function(){
    process.stdout.write('end');
})
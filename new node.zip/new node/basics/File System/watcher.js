/**
* Watching files for modifications
*/
var fs = require('fs'),
path = './points.txt';
fs.watchFile(path, function(current, previous) {
	for (var key in current) {
		if (current[key] !== previous[key]) {
		    console.log(key + ' altered. prev: ' + previous[key] + ' curr: ' +
		    current[key]);
	}
}
});

fs.watch(path, function(event, filename) {
	if (filename) {
	console.log(filename + ' : ' + event);
	} else {
//Macs don't pass the filename
	console.log(path + ' : ' + event);
   }
});
﻿var fs = require('fs');
var stream = fs.createReadStream('./resource.json')

//Data event fires when a new chunk  is ready
stream.on('data', function (chunk) {
    console.log(chunk)
});

//no more data to stream
stream.on('end', function () {
    console.log('finished')
});

//This low-level access to the read stream allows  to efficiently deal with
//data as it’s read instead of waiting for it all to buffer in memory.
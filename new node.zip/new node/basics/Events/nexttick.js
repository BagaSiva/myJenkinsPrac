﻿// Memory Usage

var EventEmitter = require('events').EventEmitter;
var emitter = new EventEmitter();
setInterval(function () {
    console.log("Memory usage :" + process.memoryUsage().rss);
}, 30000);
//-----------------------------------------------------

// what is the problem with below code
var events = require('events');
function getEmitter() {
    var emitter = new events.EventEmitter();
    emitter.emit('start');
    return emitter;
}
var myEmitter = getEmitter();
myEmitter.on("start", function () {
    console.log("Started");
});

/*
The event emitter instantiated within
getEmitter emits "start" previous to being returned, wrong-footing the subsequent
assignment of a listener, which arrives a step late, missing the event notification.
*/


//To solve this race condition we can use process.nextTick:

var events = require('events');
function getEmitter() {
    
    var emitter = new events.EventEmitter();
    process.nextTick(function() {
        emitter.emit('start');
    });
    return emitter;
}
var myEmitter = getEmitter();
myEmitter.on('start', function() {
    console.log('Started');
})
//
//Here the attachment of the on(start handler is allowed to occur prior to the
//emission of the start event by the emitter instantiated in getEmitter.
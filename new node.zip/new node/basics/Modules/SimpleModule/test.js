﻿var calc = require('./calculator');
console.log("Result of add function :"+calc.add(10,20));
calc.perform();


var Account = require('./Account.js');
// instantiate and invoke
var account = new Account();
account.perform();
account.foo(10,20);

/*
var currency = require('./currency');

console.log('50 Canadian dollars equals this amount of US dollars:');
console.log(currency.canadianToUS(50));

console.log('30 US dollars equals this amount of Canadian dollars:');
console.log(currency.USToCanadian(30));

*/
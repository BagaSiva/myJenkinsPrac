﻿/*
// private members
var canadianDollar = 0.91;

function roundTwoDecimals(amount) {
    return Math.round(amount * 100) / 100;
}


exports.canadianToUS = function (canadian) {
    return roundTwoDecimals(canadian * canadianDollar);
}

exports.USToCanadian = function (us) {
    return roundTwoDecimals(us / canadianDollar);
}
*/


// multple functions in module
var calculate = function (numA, numB) {
    return numA * numB + 10 * numB;
}

var add = function (numA, numB) {
    return numA + numB;
}
var perform = function () {
    console.log("I am perform function");
}
exports.calculate = calculate;
exports.add = add;
exports.perform = perform;
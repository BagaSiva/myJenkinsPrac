﻿function Greeter (lang) {
    this.language = lang;
    this.greet() = function () {
        switch (this.language) {
            case "en": return "Hello!";
            case "de": return "Hallo!";
            default: return "No speaka that language";
        }
    }
}
exports. hello_world = function () {
    console.log("Hello World");
}
exports. goodbye = function () {
    console.log("Bye bye!");
}
exports.create_greeter = function (lang) {
    return new Greeter(lang);//factory
}

// constructor module
function ABC() {
    this.varA = 10;
    this.varB = 20;
    this.functionA = function (var1, var2) {
        console.log(var1 + " " + var2);
    }
}
module.exports = ABC;
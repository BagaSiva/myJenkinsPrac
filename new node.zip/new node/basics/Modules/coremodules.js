﻿// node modules global path 
//C:\Users\%USERNAME%\AppData\Roaming\npm\node_modules


var fs = require('fs'); // file system module. No js extension .
// core module - no path
fs.writeFileSync('bio.txt', 'Learning  node js');
console.log(fs.readFileSync('bio.txt').toString());

// path normalizes the slashes as per the OS  (backslah / forward slash)
var path = require('path');// To work with file path
var websiteHome = "Desktop/murthy//temp/index.html";
var websiteAbout = "Desktop/murthy/temp/about.html";

console.log(path.normalize(websiteHome));
//output
//Desktop\murthy\temp\index.html    in windows

console.log(path.dirname(websiteAbout));//Desktop/murthy/temp
console.log(path.basename(websiteAbout));//index.html
console.log(path.extname(websiteAbout));//.html
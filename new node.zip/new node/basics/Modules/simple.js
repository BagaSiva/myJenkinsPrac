﻿/*

Node  features are available in modules
Node is shipped with built-in modules called core modules
public modules are available with npm (Templates,dev tools, db connectors...)

built-in modules:
  var http=require('http')// http.js
  var url=require('url')  //url.js

  //third party modules
  var bcrypt=requre('bcryptjs');
  var mymod=require('./mymodule');// get mymodule.js from current folder
  var mymod=require('../anothermodule');// get from parent folder

  How module works?
  
  Export public members and keep others private
 */
  var exports={};
  (function(){
      var x=10;
      exports.foo=x*10;
  })();

  console.log(exports.x);//undefined
  console.log(exports.foo);//100


﻿var movies = require('./movies');
// movies.favMovie = 'Avatar';    not required as it is automatically set
console.log('Raj  favorite movie is :' + movies.favMovie);
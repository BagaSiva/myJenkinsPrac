﻿require('./sri');
require('./raj')

// Avatar is same for both sri and raj.  This is default behavior of module in node js
// advantage -  share memory, performance  - useful for chat room   as object reference is same

// To overcome this behavior use  object factory  to get own copy for sri and raj
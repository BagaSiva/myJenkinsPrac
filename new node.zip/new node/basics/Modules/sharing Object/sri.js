﻿var movies = require('./movies');
movies.favMovie = 'Avatar';
console.log('Sri   favorite movie is :' + movies.favMovie); // avatar
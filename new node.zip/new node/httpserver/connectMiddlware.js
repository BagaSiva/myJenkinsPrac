﻿//connect middleware from sencha
// Requires
var connect = require('connect');

// Configuration
var appConfig = {
    staticPath: __dirname // __dirname+'/static'
};

// Server
var app = connect()
    .use(connect.static(appConfig.staticPath))
    .use(function (req, res, next) {
        res.statusCode = 404;
        res.end('404 Not Found. Sorry.\n');
    })
    .listen(8000);

//Middlewares are like a waterfall, it hits the first, then if the first doesn't know what to do, the logic will flow through to the next middleware
//(accomplished by the previous middleware calling the next callback inside it).
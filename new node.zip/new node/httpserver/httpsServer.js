
/**
* HTTPS server
*/

/*
Creating TLS/SSL Keys and Certificates on Unix
$ openssl genrsa -out privatekey.pem 1024
$ openssl req -new -key privatekey.pem -out certrequest.csr
$ openssl x509 -req -in certrequest.csr -signkey privatekey.pem -out certificate.pem
*/

/*
try:  
openssl genrsa 1024 > key.pem
openssl req -x509 -new -key key.pem > key-cert.pem


On Windows this is slightly different, because Windows does not include an OpenSSL implementation by default.
You should first download a binary distribution from http://openssl.org/related/binaries.html. By default, this
will install to C:\OpenSSL-Win32 on your machine. From there you can open up PowerShell and run the following
from the C:\OpenSSL-Win32\bin directory.

PS C:\OpenSSL-Win32\bin> .\openssl.exe genrsa –out privatekey.pem 1024
PS C:\OpenSSL-Win32\bin> .\openssl.exe req –new –key .\privatekey.pem –out certrequest.csr
PS C:\OpenSSL-Win32\bin> .\openssl.exe x509 –req –in .\certrequest.csr –signkey .\privatekey.pem
–out certificate.pem

*/

var https = require('https');
var fs = require('fs');

var options = {
	key: fs.readFileSync('privatekey.pem'),
	cert: fs.readFileSync('certificate.pem')
	};

https.createServer(options, function (req, res) {
	res.writeHead(200);
	res.write("https!\n");
	res.end();
}).listen(8080);
console.log("https server running on localhost:8080");

/*


Creating an HTTPS connection starts with TLS/SSL. This protocol ensures a secure communication between the
client and the server. This occurs because there is a handshake between client and server in which the server reveals
its certificate and public key to the client. Then when the client sends a response, it is encrypted with the server’s
public key, which is validated. If all the data are evaluated to be valid, the session continues over HTTPS.

*/


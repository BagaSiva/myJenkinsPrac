//In Node.js, web servers are typically set up by using 
//the HTTP module. This provides a layer in which to interact with
//the HTTP protocol.

/**
* Setting up an HTTP server
*/
var http = require('http');
var server = http.createServer(function(req, res) {
	res.write('Hello http server');
	res.end();
});
server.listen(8080);
console.log("Web server running on localhost:8080")
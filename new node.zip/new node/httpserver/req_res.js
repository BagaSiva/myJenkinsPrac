// Understanding http Request and Response
var http = require('http');

function handle_incoming_request(req, res) {
	console.log("Request Header of http :")
    console.log("---------------------------------------------------");
    console.log(req.headers);
    console.log("---------------------------------------------------");
    console.log("http response :............................ ")
    console.log(res);
    console.log("---------------------------------------------------");
    res.writeHead(200, { "Content-Type" : "application/json" });
    res.end(JSON.stringify( { title:'Understanding Request and Response' }) + "\n");
}


var s = http.createServer(handle_incoming_request);
s.listen(8080);
console.log("http server running on localhost:8080")


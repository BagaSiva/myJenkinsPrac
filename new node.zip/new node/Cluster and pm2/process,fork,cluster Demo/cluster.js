var cluster = require('cluster');
var numCPUs = require('os').cpus().length;

if (cluster.isMaster) {

   for (var i = 0; i < numCPUs; i++) {
     cluster.fork();
   }

   cluster.on('exit', function(worker, code, signal) {
     console.log('worker ' + worker.process.pid + ' died');
   });
} else {
     //change this line to Your Node.js app entry point.
     require("./app.js");
}

// node cluster.js
/* 
As I have I5 Quadracore system in lenova, 4 processers are running on same port

Running at port  3000
Running at port  3000
Running at port  3000
Running at port  3000
*/

// in browser, open chrome and type localhost:3000

// this is with PM2 module 
//pm2 start  app.js -i 4  
//parent.js called this
process.on('message', function(msg) {
	console.log('Parent said: ', msg);
	process.send("I am fine! bye");
	//process.abort();
	process.disconnect();
    // child=null;
});


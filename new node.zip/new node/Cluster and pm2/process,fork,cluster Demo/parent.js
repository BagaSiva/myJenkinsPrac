//A fundamental part of Node's design is to create a thread pool

var cp = require('child_process');
var child = cp.fork(__dirname + '/child.js');// running on child process

child.on('message', function(msg) {
	console.log('Child said: ', msg);
});

child.send("How are you my child");

child.on('close', function () {
    console.log("child closed")
})
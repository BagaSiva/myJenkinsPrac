#!/bin/sh
echo "running this shell script from child_process.execFile"
# run another node process
node spawndemo.js
# and another
node  execfile.js
ps ax | grep node
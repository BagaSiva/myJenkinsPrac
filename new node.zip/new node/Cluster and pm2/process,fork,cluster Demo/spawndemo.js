//The spawn() method returns streams (stdout & stderr) 
//and it should be used  when the process returns large amount of data. 
//spawn() starts receiving the response as soon as the process starts executing

const fs = require('fs');
const child_process = require('child_process');
 
for(var i=0; i<3; i++) {
    var workerProcess = child_process.spawn('node', ['support.js', i]);

    workerProcess.stdout.on('data', function (data) {
        console.log('stdout: ' + data);
    });

    workerProcess.on('close', function (code) {
        console.log('child process exited with code ' + code);
    });
    }


/*
Parameters
Here is the description of the parameters used:
•	command         String    The command to run
•	args            Array List of string arguments
•	options         Object may comprise one or more of the following options:
o	cwd              String  Current working directory of the child process
o	env             Object  Environment key-value pairs
o	stdio           Array|String Child's stdio configuration
o	customFds   Array Deprecated File descriptors for the child to use for stdio
o	detached    Boolean The child will be a process group leader
o	uid             Number Sets the user identity of the process.
o	gid             Number Sets the group identity of the process.


*/
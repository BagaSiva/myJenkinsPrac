// virtual hosts  with multi process
// load balancing taken care by http-proxy with round-robin
var httpProxy = require('http-proxy');// download this module
// npm install -g http-proxy
var addresses = [
	{
		host: 'one.example.com',
		port: 8080
	},
	{
		host: 'two.example.com',
		port: 8081
	}
];
httpProxy.createServer(function(req, res, proxy) {
	var target = addresses.shift();
	proxy.proxyRequest(req, res, target);
	addresses.push(target);
}).listen(80);
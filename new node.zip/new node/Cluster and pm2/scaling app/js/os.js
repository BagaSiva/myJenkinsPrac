var os = require('os');

//	Total and free memory
//
console.log("Total memory :"+os.totalmem());
console.log("Free memory :"+os.freemem());
console.log("no. of Cores "+os.cpus().length);
//	Information about CPUs, as an Array
console.log("............................ CPU details :")
console.log(os.cpus());

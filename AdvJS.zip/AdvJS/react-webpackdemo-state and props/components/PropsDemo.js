import React from 'react';
import StatefulApp from './statefulApp';

class PropsDemo extends React.Component {	
   
   render() {
      return (
         <div>
       <StatefulApp/>
<h1 className='text-success'>{this.props.headerProp}</h1>
<h3 className='text-danger'>{this.props.contentProp}</h3>
         </div>
      );
   }
}

PropsDemo.defaultProps = {
   headerProp: "Header from props...",
   contentProp:"Corporate Trainings online"
}

export default PropsDemo;

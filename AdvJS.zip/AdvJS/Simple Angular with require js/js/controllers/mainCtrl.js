﻿// once the app module is loaded, callback is executed to create controller

require(['app'], function (app) {

    app.controller('mainCtrl', function ($scope) {
       this.message = "Welcome to dynamic module loader with require js";
        $scope.name = "hello Mr. Murthy";
    })
})
﻿require.config({
    paths: {
        'angular': "../lib/angular"        
    },
    // require js does not recognize angular , write shim
    shim: {
        'angular': {
            exports: 'angular'
        }
    }
});

//load the dependency mainCtrl.js initially
require (['controllers/mainCtrl'])

import 'babel-polyfill';
import React from 'react';
import ReactDOM from 'react-dom';
import {Provider} from 'react-redux';
import {createStore} from 'redux';

//store is ready
import allReducers from './reducers';
//component
import App from './components/app';

//import store

//step1 : create store
const store=createStore(allReducers);
//import Reducers


//connect store with provider  with app
ReactDOM.render(
    <Provider store={store}>
        <App />
    </Provider>,
    document.getElementById('root')
);




//level 1 : understanding Jade layout with express routing

//load the module
var express=require('express');

// connect to express web server
var app=express();
// configure template engine used by express
app.set('view engine','jade');

app.locals.pretty=true;// will display nicely formatted html in view page source of browser

app.get('/',function (req,res){
	res.render('index.jade');
});

app.get('/register',function(req,res){
	res.render('register.jade');
});

app.get('/login',function(req,res){
	res.render('login.jade');
});

app.get('/dashboard',function(req,res){
	res.render('dashboard.jade');
});
app.get('/logout',function (req,res){
	res.redirect('/');
})
app.listen(3000);
console.log("server running on localhost:3000");

// run  now     > node app1.js
// open  browser and type localhost:3000/
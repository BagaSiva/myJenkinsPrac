﻿var express = require('express')
var app = express()

app.set('views', __dirname + '/public/views')
app.set('view engine', 'jade')

app.use(express.static(__dirname + '/public'))
//all jade files are stored in public/views folder

app.get('/', function (req, res) {
    res.render('index',
    { title: 'Home page of Murthy' }
    )
})

app.listen(8000)
console.log("Express running  at localhost:8000")
/**
* Reading a file
*/
var fs = require('fs'), args;
args = process.argv.splice(2);

args.forEach(function (arg) {
    //async read
    fs.readFile(arg, 'utf8', function (err, data) {
        if (err) console.log(err);
        console.log(data);
    });
});
                                                                      
// To run    : node readingfile.js  points.txt
﻿var fs = require("fs");

// Create a readable stream
var readerStream = fs.createReadStream('main.js');

// Create a writable stream
var writerStream = fs.createWriteStream('final.js');

// Pipe the read and write operations
// read main.js and write data to final.txt
readerStream.pipe(writerStream);

console.log("Piping Ended");

﻿//Node implements File I/O using simple wrappers around 
//standard POSIX functions. 
//Node File System (fs) module can be imported using  var fs = require("fs")

var fs = require("fs");

// Asynchronous - Opening File
console.log("Going to open file!");
fs.open('webserver.js', 'r+', function (err, fd) {
    if (err) {
        return console.error(err);
    }
    console.log("File opened successfully!");
});


// Asynchronous read - Non blocking
fs.readFile('webserver.js', function (err, data) {
    if (err) {
        return console.error(err);
    }
    console.log("Asynchronous reading: " + data.toString());
});
// Synchronous read -Blocking
var data = fs.readFileSync('webserver.js');
console.log("Synchronous read: " + data.toString());

console.log("Going to get file info!");
fs.stat('main.js', function (err, stats) {
    if (err) {
        return console.error(err);
    }
    console.log(stats);
    console.log("Got file info successfully!");

    // Check file type
    console.log("isFile ? " + stats.isFile());
    console.log("isDirectory ? " + stats.isDirectory());
});

//writing stream

console.log("Going to write some content");
fs.writeFile('hello.txt', 'Hi! Learning writing ',  function(err) {
    if (err) {
        return console.error(err);
    }
})






console.log("Delete an existing file");
fs.unlink('output.txt', function (err) {
    if (err) {
        return console.error(err);
    }
    console.log("File deleted successfully!");
});


console.log("created directory /tmp/test");
fs.mkdir('/tmp/test', function (err) {
    if (err) {
        return console.error(err);
    }
    console.log("Directory created successfully!");
});

//read directory
fs.readdir("/tmp/", function (err, files) {
    if (err) {
        return console.error(err);
    }
    files.forEach(function (file) {
        console.log(file);
    });
});



console.log("End of execution");
//fs.close(fd, callback)
//fs.unlink(path, callback)    to delete the file
//fs.mkdir(path[, mode], callback)
//fs.rmdir(path, callback)




/*
fs.open(path, flags[, mode], callback)
•	path - This is string having file name including path.
•	flags - Flag tells the behavior of the file to be opened. All possible values have been mentioned below.
•	mode - This sets the file mode (permission and sticky bits), but only if the file was created. It defaults to 0666, readable and writeable.
•	callback - This is the callback function which gets two arguments (err, fd).

Flag	Description
-------------------
r	    Open file for reading. An exception occurs if the file does not exist.
r+	    Open file for reading and writing. An exception occurs if the file does not exist.
rs	    Open file for reading in synchronous mode.
rs+	Open file for reading and writing, telling the OS to open it synchronously. See notes for 'rs' about using this with caution.
w	    Open file for writing. The file is created (if it does not exist) or truncated (if it exists).
wx	    Like 'w' but fails if path exists.
w+	Open file for reading and writing. The file is created (if it does not exist) or truncated (if it exists).
wx+	Like 'w+' but fails if path exists.
a	    Open file for appending. The file is created if it does not exist.
ax	    Like 'a' but fails if path exists.
a+	    Open file for reading and appending. The file is created if it does not exist.
ax+	Like 'a+' but fails if path exists.

Get File information :    fs.stat(path, callback)

Method	Description
---------------------
stats.isFile()	                Returns true if file type of a simple file.
stats.isDirectory()	         Returns true if file type of a directory.
stats.isBlockDevice()	    Returns true if file type of a block device.
stats.isCharacterDevice()	Returns true if file type of a character device.
stats.isSymbolicLink()	    Returns true if file type of a symbolic link.
stats.isFIFO()	                Returns true if file type of a FIFO.
stats.isSocket()	            Returns true if file type of asocket.


fs.writeFile(filename, data[, options], callback)

*/
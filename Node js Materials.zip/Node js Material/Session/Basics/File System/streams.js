﻿/*
Streams are objects that allows to read data from a source or write data to a destination in continous fashion.
In Node.js, there are four types of streams.

•	Readable - Stream which is used for read operation.
•	Writable - Stream which is used for write operation.
•	Duplex - Stream which can be used for both read and write operation.
•	Transform - A type of duplex stream where the output is computed based on input.

Each type of Stream is an EventEmitter instance and throws several events at different instance of times.

Commonly used events are:

•	data - This event is fired when there is data  available to read.- 
•	readable - This event is fired when there is data read from process.- 
•	end - This event is fired when there is no more data to read.
•	error - This event is fired when there is any error receiving or writing data.
•	finish - This event is fired when all data has been flushed to underlying system

Streams represent an abstract interface for asynchronously manipulating a continuous flow of data. 

They are similar to Unix pipes and can be classified into five types: 
    readable, writable, transform, duplex and "classic".

As with Unix pipes, Node streams implement a composition operator called .pipe(). 
The main benefits of using streams are that you don't have to buffer the 
whole data into memory and they're easily composable.
*/

var fs = require("fs");
var data = '';

// Create a readable streams
var readerStream = fs.createReadStream('streamwriter.js');

// Set the encoding to be utf8. 
readerStream.setEncoding('UTF8');

// Handle stream events --> data, end, and error
readerStream.on('data', function (chunk) {
    data += chunk;
});

readerStream.on('end', function () {
    console.log(data);
});

readerStream.on('error', function (err) {
    console.log(err.stack);
});


/*
var fs = require('fs');
var contents;

var rs = fs.createReadStream("simple_stream.js");
rs.on(' readable ', function () {
    var str;
    var d = rs.read();
    if (d) {
        if (typeof d == 'string') {
            str = d;
        } else if (typeof d == 'object' && d instanceof Buffer) {
            str = d.toString('utf8');
        }
        if (str) {
            if (!contents)
                contents = d;
            else
                contents += str;
        }
    }
});
rs.on('end', function () {
    console.log("read in the file contents: ");
    console.log(contents.toString('utf8'));
});
*/





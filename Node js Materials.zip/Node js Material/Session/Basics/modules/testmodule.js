var testModule = require('./myFirstModule');
console.log(testModule.describe());

/*
steps for writing and publishing custom module
1. Create a custom module  myfirstmodule.js
    and write code

2. write testmodule.js to test the custom module
   by running node testmodule.js   
       (consume module with require)

3. create package.json to publish using npm init command
   and answer all questions.

4. npm addUser  (enter username, password and emailid)
   to register with npm site

5. to publish     -   npm publish

6. to consume     > npm install nodelab@1.0.0 
   and run   node testmodule.js  - Enjoy the output

*/
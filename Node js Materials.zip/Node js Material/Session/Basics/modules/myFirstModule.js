/**
* MyFirstModule module
*/
var _getType = function () {
    return 'CommonJS Module private Function';
};

module.exports.describe = function () {
  return 'I am a CommonJS Module with Private function :'+_getType();
};
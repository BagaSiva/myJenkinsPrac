﻿/*
Node.js - Utility Modules
--------------------------
Web Module: Provides services as web server
OS Module  : Provides basic operating-system related utility functions.
Path Module : Provides utilities for handling and transforming file paths.
Net Module  :Provides both servers and clients as streams. Acts as a network wrapper.
DNS Module :Provides functions to do actual DNS lookup.
Domain Module: Provides way to handle multiple different I/O operations as a single group.
*/
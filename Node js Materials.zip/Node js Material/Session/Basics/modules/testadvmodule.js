﻿var ABCClass = require('./advmodule');
var obj = new ABCClass();
obj.functionA(1, 2);

/**
* Custom Events

create an event that executes after a timeout period has expired
 that will occur when an operation completes. 
This then will call a function, doATask, which will return a
status of whether the operation was successful or failed
*/
var events = require('events'),
	emitter = new events.EventEmitter();

function doATask(status) {
	if (status === 'success') {
		emitter.emit('taskSuccess'); // Specific event
	} else if (status === 'fail') {
		emitter.emit('taskFail');
	}
  }

emitter.on('taskSuccess', function() {
	console.log('task success!');
});

emitter.on('taskFail', function() {
	console.log('task fail');
});

// call task with success status
setTimeout(doATask, 500, 'success');
// set task to fail
setTimeout(doATask, 1000, 'fail');
﻿// Import events module
var events = require('events');
// Create an eventEmitter object
var eventEmitter = new events.EventEmitter();

// Create an event handler as follows
var connectHandler = function connected() {
    console.log('connection succesful.');

    // Fire the data_received event 
    eventEmitter.emit('data_received');
}

// Bind the connection event with the handler
eventEmitter.on('connection', connectHandler);

// Bind the data_received event with the anonymous function
eventEmitter.on('data_received', function () {
    console.log('data received succesfully.');
});

// Fire the connection event 
eventEmitter.emit('connection');
console.log("Program Ended.");

//Ouput :
//connection succesful.
//data received succesfully.
//Program Ended.

//Event Emitter methods
/*
        addListener(event, listener)
        on(event, listener)
        once(event, listener)
        removeListener(event, listener)
        removeAllListeners([event])
        setMaxListeners(n) (warns default if more than 10 listeners attached - for memory leaks)
        listeners(event)  //Returns an array of listeners for the specified event
        emit(event, [arg1], [arg2], [...])
            Execute each of the listeners in order with the supplied arguments. Returns true if event had listeners, false otherwise.

*/                                                                                                                 
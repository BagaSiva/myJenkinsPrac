/**
* Console
*/
console.log('console usage in Node.js');
console.info('console.info writes the', 'same as console.log');
console.error('same as console.log but writes to stderr');
console.warn('same as console.err');
console.time('timer');
setTimeout(console.timeEnd, 2e3, 'timer');
console.dir({ name: 'console.dir', logs: ['the', 'string representation', 'of objects']});
var yo = 'yo';
console.trace(yo);
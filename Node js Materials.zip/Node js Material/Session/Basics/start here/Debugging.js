// Node.js runs on Google’s V8, which has a built-in debugging mechanism.
//  Node.js allows you to   debug the source utilizing this tool. 

/**
* Debugging

tell the V8 debug mechanism to pause execution of your
program. This process begins by starting your Node.js application with the ‘debug’ flag.


$ npm install -g node-inspector
$ node-inspector
Node Inspector v0.3.1
info - socket.io started
Visit http://127.0.0.1:8080/debug?port=5858 to start debugging.

Beginning Node Inspection by Creating a Server
$ node --debug  file.js
debugger listening on port 5858
*/
var http = require('http'),
mod = require('./myutility.js');
server = http.createServer(function(req, res) {
	if (req.url === '/') {
	debugger;
	mod.doSomething(function(err, data) {
		if (err) res.end('an error occured');
		res.end(JSON.stringify(data));
	});
} else {
	res.end('404');
	}
});
server.listen(8080);

/*  c:..> node debug debugging.js
< debugger listening on port 5858
connecting... ok
break in debugging.js:5
3 
4
5 var http = require('http'),
6 mod = require('./myutility.js');
7
debug>
*/

/*
  debug> watch('req.url')  // watch the req.url

  debug> watchers
0: req.url = "<error>"

// Set breakpoint in line 21
debug> sb(21)
debug> sb('myutility.js', 5)    // set breakpoint in another file

debug> s    // for step mode execution
debug>c   for continue
debug> n   //  next
debug> o  // step out

*/

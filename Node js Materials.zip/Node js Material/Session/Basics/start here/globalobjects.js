﻿//Node.js global objects are global in nature and they are available in all modules. 
//We do not need to include these objects in our application, rather we can use them directly

/*

__filename

The __filename represents the filename of the code being executed.
This is the resolved absolute path of this code file.  (two Underscores)

__dirname
The __dirname represents the name of the directory that the currently executing script resides in.

setTimeout(cb, ms)
setInterval()
Console
Process

*/

console.log(__filename);  // see the output  full path with filename
console.log(__dirname);
function display() {
    console.log("Welcome to global objects");
}
// Now call above function after 2 seconds
var t = setTimeout(display, 2000);
//clearTimeout(t);
setInterval(display, 2000);

﻿// node modules global path 
//C:\Users\%USERNAME%\AppData\Roaming\npm\node_modules
console.log("welcome to Node js");
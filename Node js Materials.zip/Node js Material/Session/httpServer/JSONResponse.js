var http = require('http');
var server = http.createServer(function(req, res) {
	res.setHeader('Content-Type', 'application/json');
	res.writeHead(200, 'json content');
	res.write('{ "name": "Murthy" }');
	res.end();
});
server.listen(8080);
console.log("Server running on localhost:8080");
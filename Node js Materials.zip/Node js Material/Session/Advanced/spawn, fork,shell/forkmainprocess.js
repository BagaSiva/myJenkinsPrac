/**
* .fork main 	
*/
var cp = require('child_process');
http = require('http');
var child = cp.fork('forkchild.js');
var server = http.createServer(function(req, res) {
	res.end('hello');
}).listen(8080);
child.send('hello');
child.send('server', server);
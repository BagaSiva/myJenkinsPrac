//Within your application, you need to execute a file as a child process to
//your Node.js process


/**
* execFile
*/
var execFile = require('child_process').execFile;
execFile('./shell.sh', function(error, stdout, stderr) {
console.log(stdout);
console.log(stderr);
console.log(error);
});
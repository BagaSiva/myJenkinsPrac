﻿//The fork method
//child_process.fork method is a special case of the spawn() to create Node processes.

//create a child process in Node.js but you also need to be able
// to easily communicate between these child processes.

const fs = require('fs');
const child_process = require('child_process');


process.on('uncaughtexception', function (err) {
    console.log(err);
})

for(var i=0; i<3; i++) {
    var worker_process = child_process.fork("support.js", [i]);	

    worker_process.on('close', function (code) {
        console.log('child process exited with code ' + code);
    });
}

// node forkdemo.js



















/*
Parameters
Here is the description of the parameters used:
•	modulePath String The module to run in the child
•	args Array List of string arguments
•	options Object may comprise one or more of the following options:
o	cwd String Current working directory of the child process
o	env Object Environment key-value pairs
o	execPath String Executable used to create the child process
o	execArgv Array List of string arguments passed to the executable (Default: process.execArgv)
o	silent Boolean If true, stdin, stdout, and stderr of the child will be piped to the parent, otherwise they will be inherited from the parent, see the "pipe" and "inherit" options for spawn()'s stdio for more details (default is false)
o	uid Number Sets the user identity of the process.
o	gid Number Sets the group identity of the process.


*/
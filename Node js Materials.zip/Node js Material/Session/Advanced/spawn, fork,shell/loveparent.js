//A fundamental part of Node's design is to create sa thread pool

var cp = require('child_process');
var child = cp.fork(__dirname + '/lovechild.js');// running on child process

child.on('message', function(msg) {
	console.log('Child said: ', msg);
});

child.send("I love you my child");


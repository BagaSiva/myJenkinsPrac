// Worker process

var http = require('http');
http.createServer(function(req, res) {
	console.log(req.url);
	res.writeHead(200);
	res.end("hello world\n");
}).listen(8000);

/*
Clustering in Node.js is essentially a solution to utilize one
 Node.js module and to split worker processes, utilizing the
child_process.fork() function, all while maintaining reference
 and communication between the master and worker
processes. 

The workers can be TCP or HTTP servers, and the requests
 are handled by the master process.

 This master process then utilizes round-robin load balancing to distribute
 the load through the server. It does this by listening for
a connection, then calling a distribute method and handing
 off the processing to the worker process.


*/
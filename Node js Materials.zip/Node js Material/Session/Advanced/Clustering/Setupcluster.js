//build a cluster of processes to run your application more efficiently.


/**
* Clustering
*/
var cluster = require('cluster'),
http = require('http'),
cpuCount = require('os').cpus().length;  // returns number of Cores in machine
	if (cluster.isMaster) { //master can create child processes and manages
		for (var i = 0; i < cpuCount; i++) {
	cluster.fork();
}

cluster.on('fork', function(worker) {
	console.log(worker + ' worker is forked');
});

cluster.on('listening', function(worker, address) {
	console.log(worker + ' is listening on ' + address);
});

cluster.on('online', function(worker) {
	console.log(worker + ' is online');
});

cluster.on('disconnect', function(worker) {
	console.log(worker + ' disconnected');
});

cluster.on('exit', function(worker, code, signal) {
	console.log('worker ' + worker.process.pid + ' died');
});
} else {
// Workers can share any TCP connection
// In this case it is an HTTP server
http.createServer(function(req, res) {
	res.writeHead(200);
	res.end("hello world\n");
	}).listen(8000);
}

//Now you will configure the cluster to execute a
// second Node.js file, once for each core on your machine
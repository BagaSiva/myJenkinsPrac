// Server socket listening to events  data,end and error
var net = require('net');

var server = net.createServer(function(connectionListener) {
//get connection count
	this.getConnections(function(err, count) {
	if (err) {
		console.log('Error getting connections');
	} else {
	// send out info for this socket
connectionListener.write('connections to server: ' + count + '\r\n');
		}
    });
//Disconnect logic	
connectionListener.on('end', function() {
	console.log('disconnected');
});
//Make sure there is something happening
connectionListener.write('Hello socket from server\r\n');
connectionListener.on('data', function(data) {
	console.log('message for you from client: ' + data);
	});
// Handle connection errors
connectionListener.on('error', function(err) {
	console.log('server error: ' + err);
	});
});

server.listen(8181, function() {
	console.log('Socket server is running on port 8181 .....');
});
/**
* Verifying file integrity - hash the response
*/
var http = require('http'),
fs = require('fs'),
crypto = require('crypto');

var req = http.get('http://nodejs.org/dist/v0.10.10/node.exe', 
	function(res) {
		var hash = crypto.createHash('sha1');
		res.on('data', function(data) {
		hash.update(data);
	});
		
res.on('end', function() {
	console.log(hash.digest('hex'));
  });
});
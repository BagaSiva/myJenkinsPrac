/**
* Different Encodings
*/
var crypto = require('crypto'),
message = 'this is a message';
console.log('sha1');
console.log(crypto.createHash('sha1').update(message).digest('hex'));
console.log(crypto.createHash('sha1').update(message).digest('base64'));
console.log(crypto.createHash('sha1').update(message).digest('binary'));
console.log('md5');
console.log(crypto.createHash('md5').update(message).digest('hex'));
console.log(crypto.createHash('md5').update(message).digest('base64'));
console.log(crypto.createHash('md5').update(message).digest('binary'));
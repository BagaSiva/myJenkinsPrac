/**
* Hashes -Building a List of Hashes Available in Node.js
*/
var crypto = require('crypto'),
hashes = crypto.getHashes();
console.log(hashes.join(', '));

//run this code to get the full list of available hashes for Node.js.
/**
* using TLS

create openSSL keys first
$ openssl genrsa -out srv-key.pem 1024
$ openssl req -new –key srv-key.pem -out src-crt-request.csr
$ openssl x509 -req -in srv-crt-request.csr -signkey srv-key.pem -out srv-cert.pem

*/
var tls = require('tls'),
fs = require('fs');

var options = {
	key: fs.readFileSync('srv-key.pem'),
	cert: fs.readFileSync('srv-cert.pem')
};

tls.createServer(options, function(s) {
	s.write('yo');
	s.pipe(s);
}).listen(8888);

/*
ca: An array of strings or buffers of trusted certificates.
• cert: A string or buffer containing the certificate key of the server in Privacy Enhanced Mail
(PEM) format. (Required)
• ciphers: A string describing the ciphers to use or exclude.
• crl : A string or list of strings of PEM-encoded certificate revocation lists (CRLs)
• handshakeTimeout: Aborts the connection if the SSL/TLS handshake does not finish in a
certain number of milliseconds. The default is 120 seconds.
• honorCipherOrder: When choosing a cipher, uses the server's preferences instead of the client
preferences.
• key: A string or buffer containing the private key of the server in PEM format. (Required)
*/

//...
var bcrypt=require('bcrypt.js');

app.post("/register", function(req, res) {
	var usrnm = req.body.name;

	User.findOne({username: usrnm}, function(err, usrData) {
		if (usrData === null) {
		//create
		bcrypt.genSalt(10, function(err, salt) {
			bcrypt.hash(req.body.pwd, salt, function(err, hash) {
				var newUser = new User({ username: usrnm, email: req.body.email, pwHash: hash });
				newUser.save(function(err) { // in mongo db
					if (err) {
						res.send({name: usrnm, message: "failure", error: err});
					return;
			}
		res.send({name: usrnm, message: "success"});
		});
	});
});	

} else {
//emit to client
	res.send({name: usrnm, message: "failure", error: "User already exists"});
		}
	});
});
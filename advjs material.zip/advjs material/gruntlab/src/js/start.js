﻿'use Strict';
var a = 5; // global variable
window.titleOfApplication = 'javascript';  // global variable attached to window object

// grouping variables - best practise
var ename= 'Murthy', sal = 5000, job = 'Eng';

function show() {  // best practise put { here now below to use ASI
    var books = ['javascript', 'java'];   
    // object Literal  (camel case) 
    empInfo = {
                'name': 'Murthy',
                'job': 'Engineer',
                'salary': 5000,
            	'address': { 'hno': "2-2-223" }
            };
}
alert("Welcome to Grunt by "+ename);

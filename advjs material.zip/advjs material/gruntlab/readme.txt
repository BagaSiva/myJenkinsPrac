
Steps:

Install node js

create package.json   (npm init)

Create src folder structure and write code

create test folder and write tests

create karma.conf.js to configure karma

Create gruntfile.js to configure tasks

$grunt

open browser and type :localhost:9001

See the output.


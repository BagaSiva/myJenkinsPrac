// Test suite - contain one or more unit tests
describe('hello javascript test', function () {
   var greeter;
// like setup which will be called before every test
// for instantion or intialization of data
  beforeEach(function () {
      greeter = new Greeter();
   });

//afterEach(function(){....})
  
  //test 
  it('should say hello to the Murthy', function () {
  	console.log(greeter.say("Murthy"));
  	// assert libray - expect.js
    expect(
    	greeter.say('Murthy')).toEqual('Hello,Murthy');
  });
});

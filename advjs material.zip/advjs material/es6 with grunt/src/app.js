import {Rectangle} from "./rectangle.js"

var r = new Rectangle(50, 20)
console.log(r.area === 1000)
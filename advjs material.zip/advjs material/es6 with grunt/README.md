
$ npm install

$grunt
